#!/bin/bash
# Calls profiles_hdf5 in a loop
# Reads in the output of specgen, and renames the specfiles to be read
# by profiles.f
# USAGE: profiles_loop_new <simulation> <short/long> <redshift> <start> <end> <ion>
# 'simulation' is the FULL name of the simulation used
# 'start' and 'end' refers to the LOS_ID to start and end with, so that the 
#
# Calls profiles_hdf5
#

# Check spectral type
if [ "$2" == "short" ]; then
spec_type='short'
elif [ "$2" == "long" ]; then
spec_type='long'
else
echo 'Wrong input parameters!'
echo 'USAGE: profiles_hdf5_loop <simulation> <short/long> <redshift> <start> <end> <ion>'
exit
fi
#

dir='output_data/'

if [ "${6}" == "h1" ]; then
 ion='HI_Lya'
elif [ "${6}" == "o6" ]; then
 ion='OVI_1032'
elif [ "${6}" == "n5" ]; then
 ion='NV_1238'
elif [ "${6}" == "ne8" ]; then
 ion='NeVIII_770'
elif [ "${6}" == "all" ]; then
if [ "${spec_type}" == "short" ]; then
echo 'profiles_loop_new:  Need to specify an ion for short spectra\n'
exit
fi
else
echo 'ERROR: profiles_hdf5_loop:  ION '${6}' not yet available!\n'
exit
fi

# Remove previous file
# rm ${dir}${1}_${spec_type}_z${3}_${6}_linepar.pro

for i in $(seq ${4} ${5}) ;
do

 echo ${i}

# Rename file with line parameters
 cp ~/autovp/${dir}${1}/${spec_type}_spec${i}_z${3}_${6}.vpm ${ion}.vpm

# Rename file with fit
 cp ~/autovp/${dir}${1}/${spec_type}_spec${i}_z${3}_${6}.cln ${ion}.cln

# Rename file with detected regions
 cp ~/autovp/${dir}${1}/${spec_type}_spec${i}_z${3}_${6}.ewr ${ion}.ewr

# Stop if something goes wrong when calling fortran programs
# (assumes fortran code stops with a return error value != 0)
set -e

# Read in line parameters and generate synthetic spectrum
 profiles_hdf5 ${ion}

# Write fitted flux and line parameters into new HDF5 spectrum file <spectype>_z<redshift>_<ion>_fit.hdf5
 write_fit_hdf5 ${1} ${spec_type} ${spec_type}_z${3}_${6}_fit.hdf5 ${i} ${ion}_SynSpec.dat ${ion}_linepar.dat ${ion}.ewr ${6}

# Restore set
set +e

# Removing unnecesary files
 rm ${ion}_SynSpec.dat
 rm ${ion}_linepar.dat
 rm ${ion}.*
 rm ~/autovp/${dir}${1}/${spec_type}_spec${i}_z${3}_${6}.cln
 rm ~/autovp/${dir}${1}/${spec_type}_spec${i}_z${3}_${6}.vpm
 rm ~/autovp/${dir}${1}/${spec_type}_spec${i}_z${3}_${6}.ewr

done
